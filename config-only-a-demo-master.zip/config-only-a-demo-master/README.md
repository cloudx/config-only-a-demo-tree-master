# config-only-a-demo
仅仅是一个为测试 Spring Cloud Config 建立的测试项目


测试 Spring Cloud Config 所用
